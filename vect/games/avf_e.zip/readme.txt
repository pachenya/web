Alien vs Farmer version 1.0.0
Windows95/98 game

This game is the story of a farmer.
He revenge f**king FUOs that killed his cows and drew mistery circles
on his field.

*** Tutorial ***
1. Run "avf.exe" from explorer.
2. Press Enter to start game.
3. Corsor key to move a man.  Z, X and C to other actions.
4. When game is over, press Enter to return to title screen.
5. Press S to show high-score in title screen.
6. When you tired or something, press Esc to quit game.

*** Controles ***
Corsor  Move
Z       Fire missiles(Auto firing)
X       Fire a lot of rockets
C       Change formation


Send any comment, question or bugreport to

k_o@mutt.freemail.ne.jp
homepage: http://hp.vector.co.jp/authors/VA018250/
